package chuckaluck;

public class Dobbelbeker {
	
	private Dobbelsteen[] stenen;
	
	public Dobbelbeker() {
		stenen = new Dobbelsteen[3];
		for(int i = 0; i < stenen.length; i++){
			stenen[i] = new Dobbelsteen(6);
		}

	}

	public int werpStenen(int getal){

		int hoeVaakHetGoedIs = 0;
		for (int i = 0; i < stenen.length; i++){
			stenen[i].werpSteen();
			if(getal == stenen[i].getAantalOgen()){
				hoeVaakHetGoedIs++;
			}
		}

		return hoeVaakHetGoedIs;
	}

	@Override
	public String toString() {
		String result = "";
		for(int i = 0; i< stenen.length; i++) {
			result += stenen[i].getAantalOgen() + " ";
		};
		return result;
	}
}
