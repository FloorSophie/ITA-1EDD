package chuckaluck;

import java.util.Random;

public class Dobbelsteen {
	private Random r;
	private int aantalZijden;
	private int aantalOgen;
	
	public Dobbelsteen(int aantalZijden) {
		r = new Random();
		this.aantalZijden = aantalZijden;
	}
	
	public void werpSteen() {
		aantalOgen = r.nextInt(aantalZijden) + 1;
		// System.out.println("werpSteen: " + aantalOgen);
	}
	
	public int getAantalOgen() {
		return aantalOgen;
	}
	
	public String toString() {
		return "" + getAantalOgen();
	}
	
}
