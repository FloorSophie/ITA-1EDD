package chuckaluck;

public class ChuckALuckSpel extends Object {

	private int aantalNGelijk;
	private int saldo;
	private int ronde;
	private int geluksgetal;
	private int inzet;
	private Dobbelbeker beker;

	public ChuckALuckSpel(int beginsaldo) {
		this.saldo = beginsaldo;
		beker = new Dobbelbeker();
	}

	public void speelRonde(int geluksgetal, int inzet) {
		this.geluksgetal = geluksgetal;
		this.inzet = inzet;
		aantalNGelijk = beker.werpStenen(geluksgetal);
		if (aantalNGelijk == 0) {
			saldo -= inzet;
		}
		if (aantalNGelijk == 1) {
			saldo += inzet;
		}
		if (aantalNGelijk == 2) {
			saldo += inzet * 2;
		}
		if (aantalNGelijk == 3) {
			saldo += inzet * 10;
		}

		ronde++;
	}

	@Override
	public String toString() {
		String result = "";
		result += "--------------------\n";
		result += "Ronde: " + ronde + "\n";
		result += "Inzet: " + inzet + "\n";
		result += "geluksgetal: " + geluksgetal + "\n";
		result += "worp: " + beker.toString() + "\n";
		result += "saldo: " + saldo + "\n";
		return result;

	}

}